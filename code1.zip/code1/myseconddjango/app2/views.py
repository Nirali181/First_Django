from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def homepageview(request):
    return HttpResponse("<center><h2>Welcome to Homepage<h2><center>")

def aboutpageview(request):
    return HttpResponse("<center><h2>Welcome to about us page<h2><center>")

def contactpageview(request):
    return HttpResponse("<center><h2>Welcome to contact page<h2><center>")
